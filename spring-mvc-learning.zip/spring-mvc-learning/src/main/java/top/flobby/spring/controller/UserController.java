package top.flobby.spring.controller;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import top.flobby.spring.entity.User;

/**
 * @author : Flobby
 * @program : spring-mvc-learning
 * @description :
 * @create : 2023-03-07 20:09
 **/

@Controller
public class UserController {
    @RequestMapping("selectUser")
    public String selectUser(HttpServletRequest request) {
        String id = request.getParameter("id");
        System.out.println("id=" + id);
        return "success";
    }

    @RequestMapping("toRegister")
    public String toRegister() {
        return "register";
    }

    @RequestMapping("/registerUser")
    public String register(User user) {
        String name = user.getName();
        String password = user.getPassword();
        System.out.println(name);
        System.out.println(password);
        return "success";
    }
}
